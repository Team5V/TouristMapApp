const jsObjectFactoryModule = () => {
  
};